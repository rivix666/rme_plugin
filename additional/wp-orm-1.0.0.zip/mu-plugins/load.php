<?php
// wp-orm load
require WPMU_PLUGIN_DIR.'/wp-orm/wp-orm.php';

// Sentry Load
$wp_sentry = WPMU_PLUGIN_DIR.'/../plugins/wp-sentry-integration/wp-sentry.php';

if (!file_exists($wp_sentry)) {
    return;
}

require $wp_sentry;

define('WP_SENTRY_MU_LOADED', true);